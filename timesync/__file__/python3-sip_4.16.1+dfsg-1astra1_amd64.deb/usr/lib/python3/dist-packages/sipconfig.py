# Import the sipconfig.py for the correct python3 version and normal or debug
# build.

import sys

if sys.version_info[1] == 2:
    if 'd' in sys.abiflags:
        try:
            from sipconfig_d2 import *
            from sipconfig_d2 import _pkg_config, _default_macros
        except ImportError as msg:
            raise ImportError('No module named sipconfig; package python3-sip4-dbg not installed')
    else:
        from sipconfig_nd2 import *
        from sipconfig_nd2 import _pkg_config, _default_macros

